<?php
   include 'cart.php';
   
   $products = $num_of_products;
?>
